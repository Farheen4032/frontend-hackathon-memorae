// Simple JS: mobile nav, form demo behavior, set year
document.addEventListener('DOMContentLoaded', function(){
  const navToggle = document.getElementById('navToggle');
  const nav = document.getElementById('nav');
  if(navToggle){
    navToggle.addEventListener('click', ()=> {
      const isOpen = nav.style.display === 'flex';
      nav.style.display = isOpen ? 'none' : 'flex';
    });
  }

  // contact form demo
  const form = document.getElementById('contactForm');
  const submitBtn = document.getElementById('submitBtn');
  const formMessage = document.getElementById('formMessage');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      submitBtn.disabled = true;
      submitBtn.textContent = 'Sending...';
      // simulate network
      setTimeout(()=> {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Request demo';
        formMessage.textContent = 'Thanks — we will contact you soon. (Demo mode)';
        form.reset();
      }, 900);
    });
  }

  const year = document.getElementById('year');
  if(year) year.textContent = new Date().getFullYear();
});
