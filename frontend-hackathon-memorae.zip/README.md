# frontend-hackathon-memorae

Purple Gradient AI Theme — HTML/CSS/JS redesign of Memorae landing page.
This repo is ready to push to GitHub and deploy (Vercel / Netlify / GitHub Pages).

## What is included
- `index.html` — single-page responsive design
- `styles/style.css` — handcrafted CSS with purple gradient theme
- `scripts/main.js` — mobile nav + demo contact form behavior
- `assets/` — logo and illustration SVGs
- Modern responsive layout and subtle animations
- No backend required (contact form is demo mode)

## How to run locally
1. Open `index.html` in your browser — or
2. Run a simple static server:
   ```bash
   npx http-server . -p 8080
   ```
   then open http://localhost:8080

## How to push to GitHub (copy & paste)
```bash
git init
git add .
git commit -m "Initial commit - Memorae redesign (Purple AI Theme)"
git branch -M main
git remote add origin https://github.com/farheen4032/frontend-hackathon-memorae.git
git push -u origin main
```

## Deployment
- Vercel: Import the GitHub repo, Vercel will auto-deploy a static site.
- Netlify: Drag & drop the repository or connect via Git.
- GitHub Pages: Use the `gh-pages` branch or configure Pages from the `main` branch.

## Video script (2-min)
1. Intro: "Hi, I'm Farheen — this is my Memorae redesign built with HTML/CSS/JS."
2. Show hero and explain the core changes: purple gradient, clearer headline, CTAs.
3. Show features and how it works sections.
4. Show responsive behavior on mobile and contact form demo.
5. Provide repo link and live demo link.
